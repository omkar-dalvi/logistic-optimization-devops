sudo docker build -t logistic-optimization-api .
