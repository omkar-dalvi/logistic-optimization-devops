sudo docker rm -f logistic-optimization-api
sudo docker run --name logistic-optimization-api -d -p 8001:8000 logistic-optimization-api