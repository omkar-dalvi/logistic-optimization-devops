# logistic-optimization-devops
Project demonstrating logistic optimization using machine learning and using DevOps for automation
